import React, { useEffect, useState } from "react";
import { Button, Form, FormGroup, Input, Label, Alert } from "reactstrap";
import NewUserModal from "./NewUserModal";
import AuthContext from "../context/auth/AuthContext";
import { useContext } from "react";

const Login = (props) => {

  const [user, saveUser] = useState({
    email: '',
    password: ''
  });

  // destructuring
  const { email, password } = user;
  // if password or user doesn't exist
  const authContext = useContext(AuthContext)
  const { message, login, autenticated, autenticatedUser } = authContext
  useEffect(() => {
    autenticatedUser()
    if (autenticated) {
      props.history.push('/home');
    }
    
    // eslint-disable-next-line
  }, [message, autenticated, props.history]);

  const onChange = e => {
    saveUser({
      ...user,
      [e.target.name]: e.target.value
    })
  }

 
  // when login
  const onSubmit = e => {
    e.preventDefault();
    // send to action
    login({ email, password });
  }


  return (
    <div className="limiter">
      <div className="container-login100">
        <div className="wrap-login100">
          <Form onSubmit={onSubmit} encType="multipart/form-data">
            <FormGroup>
              <Label for="email">Email:</Label>
              <Input
                type="text"
                name="email"
                onChange={onChange}
                value={email}
              />
            </FormGroup>
            <FormGroup>
              <Label for="password">Password:</Label>
              <Input
                type="password"
                name="password"
                onChange={onChange}
                value={password}
              />
            </FormGroup>
            {message ?
              <Alert color="danger"> {message} </Alert> :
              null
            }
            <Button color="danger">LOGIN</Button>
            <NewUserModal
              create={true}
            />
          </Form>
          <a className="text-danger" href="/reset-password"> Forgot your password? </a>
        </div>
      </div>
    </div>
  );

}
export default Login;
