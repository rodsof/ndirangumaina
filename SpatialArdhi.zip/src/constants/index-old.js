export const API_URL_DATA = "https://www.spatialardhi.com/estate/data/?format=api";
export const API_URL_LOGIN = "https://www.spatialardhi.com/estate/login/?format=api";
export const API_URL_PROFILES = "https://www.spatialardhi.com/estate/profiles/?format=api";
export const API_URL_ADMIN = "https://www.spatialardhi.com/estate/admin/?format=api";
export const API = "https://www.spatialardhi.com/estate/data/?format=api";
