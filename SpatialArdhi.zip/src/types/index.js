export const REGISTERED = 'REGISTERED';
export const REGISTER_ERROR = 'REGISTER_ERROR';
export const GET_USER = 'GET_USER';
export const GETUSER_ERROR = 'GETUSER_ERROR';
export const LOGIN_OK = 'LOGIN_OK';
export const LOGIN_ERROR = 'LOGIN_ERROR';
export const LOG_OUT = 'LOG_OUT';